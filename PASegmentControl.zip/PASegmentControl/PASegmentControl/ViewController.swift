//
//  ViewController.swift
//  PASegmentControl
//
//  Created by shuoliu on 2017/7/3.
//  Copyright © 2017年 shuoLiu. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        let titles = ["One Day", "Two", "Three", "Four dogs", "Five fingers", "Six trees", "Seven", "Eight", "Nine", "Ten"]
        let segment = PASegmentControl.baseSegmentControl(titles: titles)
        segment.indexChangedHandler = {
            (index) in
            print("index changed: \(index)")
        }
        self.view.addSubview(segment)
        segment.reloadSegments()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

